#include "template.hpp"

#include <iostream>
#include <string>

int main() {
    const std::string expected = "Hola, Mundo Pro++!";
    const std::string actual = getGreeting();

    if (actual != expected) {
        std::cerr << "Test failed.\n";
        std::cerr << "Expected: " << expected << "\n";
        std::cerr << "Actual: " << actual << "\n";
        return 1;
    }

    std::cout << "Test passed!" << std::endl;
    return 0;
}
