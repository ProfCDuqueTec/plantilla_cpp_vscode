# Arquitectura de la plantilla

Esta plantilla separa la lógica reutilizable del programa principal.

```text
include/template.hpp
        ↓
src/saludo.cpp  →  template_core
                        ↓
        ┌───────────────┴───────────────┐
        ↓                               ↓
src/main.cpp                    test/sample_test.cpp
app ejecutable                  ejecutable de pruebas
```

## Componentes

- `template_core`: librería interna donde debe vivir la lógica reutilizable.
- `cpp_vscode_cmake_template`: ejecutable principal.
- `runTests`: ejecutable de pruebas.

## Regla importante

Cuando agregues nuevos archivos `.cpp` con lógica del proyecto, agrégalos a `template_core`, no directamente al ejecutable principal.
