# Checklist de validación

- [ ] `g++ --version` funciona.
- [ ] `cmake --version` funciona.
- [ ] `where g++` muestra una ruta válida en Windows.
- [ ] `cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_EXPORT_COMPILE_COMMANDS=ON` configura sin errores.
- [ ] `cmake --build build` compila sin errores.
- [ ] `.\build\cpp_vscode_cmake_template.exe` imprime `Hola, Mundo Pro++!`.
- [ ] `ctest --test-dir build --output-on-failure` pasa las pruebas.
- [ ] `Ctrl + Shift + B` compila desde VSCode.
- [ ] `Terminal > Run Task > Run: app` ejecuta el programa.
- [ ] `Terminal > Run Task > Test: ctest` ejecuta pruebas.
