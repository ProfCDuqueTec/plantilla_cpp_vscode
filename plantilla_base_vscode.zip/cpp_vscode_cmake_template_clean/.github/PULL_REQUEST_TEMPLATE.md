# Pull Request

## Qué cambia
Describe brevemente los cambios realizados.

## Por qué cambia
Explica la motivación o problema que resuelve.

## Checklist

- [ ] El proyecto compila.
- [ ] Las pruebas pasan.
- [ ] El README fue actualizado si era necesario.
- [ ] El código mantiene la estructura de la plantilla.
